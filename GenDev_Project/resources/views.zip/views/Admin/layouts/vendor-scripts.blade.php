<!-- JAVASCRIPT -->
<script src="{{ URL::asset('build/libs/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ URL::asset('build/libs/bootstrap/dist/js/bootstrap.bundle.js') }}"></script>
<script src="{{ URL::asset('build/libs/metismenu/dist/metisMenu.js') }}"></script>
<script src="{{ URL::asset('build/libs/simplebar/dist/simplebar.js') }}"></script>
<script src="{{ URL::asset('build/libs/node-waves/dist/waves.js') }}"></script>
@yield('scripts')