<script type="text/javascript" src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/tether.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/jquery-migrate.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/hidemaxlistitem.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/jquery-ui.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/hidemaxlistitem.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/jquery.easing.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/scrollup.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/jquery.waypoints.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/waypoints-sticky.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/pace.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/slick.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/scripts.js') }}"></script>
@stack('scripts')